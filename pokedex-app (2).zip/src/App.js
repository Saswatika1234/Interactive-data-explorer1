import React, { useEffect, useState } from 'react';

function App() {
  const [pokemons, setPokemons] = useState([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetch('https://pokeapi.co/api/v2/pokemon?limit=151')
      .then(res => res.json())
      .then(data => setPokemons(data.results));
  }, []);

  return (
    <div style={{ textAlign: 'center', fontFamily: 'Arial' }}>
      <h1>Pokedex</h1>
      <input
        type="text"
        placeholder="Search Pokémon"
        onChange={e => setSearch(e.target.value.toLowerCase())}
        style={{ padding: '8px', margin: '10px', fontSize: '16px' }}
      />
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {pokemons
          .filter(p => p.name.includes(search))
          .map((pokemon, index) => (
            <li key={index} style={{ margin: '5px 0' }}>
              {pokemon.name}
            </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
